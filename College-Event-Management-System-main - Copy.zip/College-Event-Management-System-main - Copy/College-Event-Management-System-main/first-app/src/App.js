import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './Components/Navbar';
import HomePage from './Components/HomePage';
import Login from './Components/Login';
import RegistrationForm from './Components/RegistrationForm';
import EventManagement from './Components/EventManagement';
import ProtectedRoute from './Components/ProtectedRoute';
import './App.css';
import EventList from './Components/EventList';
import Reports from './Components/Reports';
import Booking from './Components/Booking';
import Logout from './Components/Logout';
import AdminDashboard from './admin/AdminDashboard'; // Import Admin Dashboard
import ManageEvents from './admin/ManageEvents';     // Import Manage Events
import ManageReports from './admin/ManageReports';   // Import Manage Reports

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<RegistrationForm />} />
          <Route
            path="/events/manage"
            element={
              <ProtectedRoute>
                <EventManagement />
              </ProtectedRoute>
            }
          />
          <Route 
            path="/events" 
            element={
              <ProtectedRoute>
                <EventList />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/reports" 
            element={
              <ProtectedRoute>
                <Reports />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/booking" 
            element={
              <ProtectedRoute>
                <Booking />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/logout" 
            element={
              <ProtectedRoute>
                <Logout />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin" 
            element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/manage-events" 
            element={
              <ProtectedRoute>
                <ManageEvents />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/manage-reports" 
            element={
              <ProtectedRoute>
                <ManageReports />
              </ProtectedRoute>
            } 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
