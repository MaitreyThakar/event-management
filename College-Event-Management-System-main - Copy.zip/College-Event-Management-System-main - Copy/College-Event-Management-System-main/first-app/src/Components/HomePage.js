
import React, { useEffect, useState } from 'react';
import './HomePage.css'; 
import clghackathon from '../Assets/clghackathon.jpg';
import clgimg from '../Assets/clgimg.jpg';
import clgfest from '../Assets/clgfest.jpg';
import vcethackathon from '../Assets/vcethackathon.jpg'
import startup from '../Assets/startup-pitch-competition.jpg'
import culture from '../Assets/cultog.jpg'


const images = [clgimg,clghackathon,clgfest];

const HomePage = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3500); // Change image every 3 seconds

    return () => clearInterval(interval); 
  }, []);

  return (
    <div className="homepage">
      <header className="hero-section" style={{ backgroundImage: `url(${images[currentImageIndex]})` }}>
        <div className="hero-content">
          <h1>Welcome to ABC Events</h1>
          <p>Discover, manage, and attend events at ABC. Your one-stop platform for all things events.</p>
          <a href="/events" className="cta-button">Explore Events</a>
        </div>
      </header>



   
      <section className="events-section">
        <h2>PAST EVENTS</h2>
        <div className="events-cards">
      
          <div className="event-card">
            <img src={vcethackathon} alt="VCET Hackathon 2024" className="event-image" />
            <div className="event-info">
              <h3>ABC Hackathon 2024</h3>
              <p><strong>Date:</strong> October 4, 2024</p>
              <p>Join us for a 30-hour Hackathon organized by the Department of Information Technology at VCET.</p>
              <a href="#details" className="event-button">View Details</a>
            </div>
          </div>

          
          <div className="event-card">
            <img src={startup} alt="Startup Pitch Fest" className="event-image" />
            <div className="event-info">
              <h3>Startup Pitch 1</h3>
              <p><strong>Date:</strong> November 15, 2026</p>
              <p>Pitch your startup idea and compete for exciting prizes. Network with investors and entrepreneurs.</p>
              <a href="#details" className="event-button">View Details</a>
            </div>
          </div>


          <div className="event-card">
            <img src={startup} alt="Startup Pitch Fest" className="event-image" />
            <div className="event-info">
              <h3>Startup Pitch 2</h3>
              <p><strong>Date:</strong> November 15, 2020</p>
              <p>Pitch your startup idea and compete for exciting prizes. Network with investors and entrepreneurs.</p>
              { <a href="#details" className="event-button">View Details</a> }
            </div>
          </div>

          
          <div className="event-card">
            <img src={culture} alt="VCET Cultural Fest" className="event-image" />
            <div className="event-info">
              <h3>ABC Cultural Fest</h3>
              <p><strong>Date:</strong> December 5, 2025</p>
              <p>Celebrate the cultural diversity of VCET with music, dance, art, and performances from talented students.</p>
              { <a href="#details" className="event-button">View Details</a> }
            </div>
          </div>
        </div>
      </section>
    
     
      <footer className="footer">
        <p>&copy; 2024 ABC Events. All Rights Reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
