import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './EventManagement.css';

const API_URL = 'http://localhost:5001/api';

const EventManagement = () => {
  const [events, setEvents] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    date: '',
    prize: '',
    description: '',
    image: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await axios.get(`${API_URL}/events`);
      setEvents(response.data);
    } catch (err) {
      setError('Failed to fetch events');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await axios.put(`${API_URL}/events/${editingId}`, formData);
      } else {
        await axios.post(`${API_URL}/events`, formData);
      }
      setFormData({ title: '', date: '', prize: '', description: '', image: '' });
      setEditingId(null);
      fetchEvents();
    } catch (err) {
      setError('Failed to save event');
    }
  };

  const handleEdit = (event) => {
    setFormData(event);
    setEditingId(event._id);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/events/${id}`);
      fetchEvents();
    } catch (err) {
      setError('Failed to delete event');
    }
  };

  return (
    <div className="event-management">
      <h2>Event Management</h2>
      {error && <div className="error-message">{error}</div>}
      
      <form onSubmit={handleSubmit} className="event-form">
        <input
          type="text"
          placeholder="Event Title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Prize"
          value={formData.prize}
          onChange={(e) => setFormData({ ...formData, prize: e.target.value })}
          required
        />
        <textarea
          placeholder="Description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Image URL"
          value={formData.image}
          onChange={(e) => setFormData({ ...formData, image: e.target.value })}
          required
        />
        <button type="submit">{editingId ? 'Update Event' : 'Add Event'}</button>
      </form>

      <div className="events-list">
        <h3>Events</h3>
        {events.map((event) => (
          <div key={event._id} className="event-card">
            <h4>{event.title}</h4>
            <p>Date: {new Date(event.date).toLocaleDateString()}</p>
            <p>Prize: {event.prize}</p>
            <p>{event.description}</p>
            {event.image && <img src={event.image} alt={event.title} />}
            <div className="event-actions">
              <button onClick={() => handleEdit(event)}>Edit</button>
              <button onClick={() => handleDelete(event._id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventManagement; 